print("Training from the command line is no longer necessary.")
print("ChatBots now use the data/chatbot.csv file to learn and respond to users.")
